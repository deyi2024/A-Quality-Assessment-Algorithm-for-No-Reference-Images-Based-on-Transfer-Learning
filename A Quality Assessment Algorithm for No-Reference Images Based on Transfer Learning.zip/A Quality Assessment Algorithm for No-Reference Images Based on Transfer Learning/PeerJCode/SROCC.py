import numpy as np
from PIL import Image
from scipy.stats import spearmanr

def load_images(image_paths):
    images = []
    for path in image_paths:
        img = Image.open(path).convert('L')
        img_array = np.array(img)
        images.append(img_array)
    return images

def calculate_srocc(subjective_scores, predicted_scores):
    subjective_scores = np.array(subjective_scores)
    predicted_scores = np.array(predicted_scores)
    srocc, _ = spearmanr(subjective_scores, predicted_scores)
    return srocc

if __name__ == "__main__":
    image_paths = ['image1.png', 'image2.png', 'image3.png']
    images = load_images(image_paths)

    subjective_scores = [4.5, 3.0, 2.5]
    predicted_scores = [4.4, 3.2, 2.3]

    srocc_value = calculate_srocc(subjective_scores, predicted_scores)
    print(f"SROCC Value: {srocc_value}")
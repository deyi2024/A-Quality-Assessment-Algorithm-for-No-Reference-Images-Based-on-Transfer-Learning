import numpy as np
from PIL import Image
from scipy.stats import pearsonr

def load_images(image_paths):
    images = []
    for path in image_paths:
        img = Image.open(path).convert('L')
        img_array = np.array(img)
        images.append(img_array)
    return images

def calculate_plcc(subjective_scores, predicted_scores):
    subjective_scores = np.array(subjective_scores)
    predicted_scores = np.array(predicted_scores)
    plcc, _ = pearsonr(subjective_scores, predicted_scores)
    return plcc

if __name__ == "__main__":
    image_paths = ['image1.png', 'image2.png', 'image3.png']
    images = load_images(image_paths)

    subjective_scores = [4.5, 3.0, 2.5]
    predicted_scores = [4.4, 3.2, 2.3]

    plcc_value = calculate_plcc(subjective_scores, predicted_scores)
    print(f"PLCC Value: {plcc_value}")
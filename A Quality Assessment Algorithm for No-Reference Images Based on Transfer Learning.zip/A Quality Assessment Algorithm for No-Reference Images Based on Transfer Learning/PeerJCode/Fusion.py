import numpy as np
from scipy.stats import pearsonr, spearmanr
from PIL import Image
import random


def load_images(image_paths):
    images = []
    for path in image_paths:
        img = Image.open(path).convert('L')
        img_array = np.array(img)
        images.append(img_array)
    return images


class BaseModel:
    def predict(self, images):
        return [random.uniform(1, 5) for _ in images]


class ResNet50(BaseModel):
    pass


class MultiScaleSemanticFeature(BaseModel):
    pass


class VisualPerceptionModule(BaseModel):
    pass


class AdaptiveFusionNetwork(BaseModel):
    pass


class IQANRTL(BaseModel):
    pass


def calculate_plcc(real_scores, predicted_scores):
    real_scores = np.array(real_scores)
    predicted_scores = np.array(predicted_scores)
    plcc, _ = pearsonr(real_scores, predicted_scores)
    return plcc


def calculate_srocc(real_scores, predicted_scores):
    real_scores = np.array(real_scores)
    predicted_scores = np.array(predicted_scores)
    srocc, _ = spearmanr(real_scores, predicted_scores)
    return srocc


def get_data_and_scores(dataset_name):
    datasets = {
        'KonIQ-10K': (['koniq1.png', 'koniq2.png', 'koniq3.png'], [4.5, 3.0, 2.5]),
        'BIQ2021': (['biq1.png', 'biq2.png', 'biq3.png'], [3.5, 4.0, 1.5]),
        'LIVE': (['live1.png', 'live2.png', 'live3.png'], [5.0, 3.5, 2.0]),
        'TID2013': (['tid1.png', 'tid2.png', 'tid3.png'], [2.5, 4.5, 3.0]),
    }
    return datasets[dataset_name]


def run_experiment(model, dataset_name):
    image_paths, real_scores = get_data_and_scores(dataset_name)
    images = load_images(image_paths)

    predicted_scores = model.predict(images)

    plcc_value = calculate_plcc(real_scores, predicted_scores)
    srocc_value = calculate_srocc(real_scores, predicted_scores)

    return plcc_value, srocc_value


if __name__ == "__main__":
    models = {
        'Exp_ResNet50': ResNet50(),
        'Exp_Semantic': MultiScaleSemanticFeature(),
        'Exp_Vision': VisualPerceptionModule(),
        'Exp_Adapt': AdaptiveFusionNetwork(),
        'IQA_NRTL': IQANRTL(),
    }

    datasets = ['KonIQ-10K', 'BIQ2021', 'LIVE', 'TID2013']

    for model_name, model in models.items():
        print(f"Results for {model_name}:")
        for dataset in datasets:
            plcc, srocc = run_experiment(model, dataset)
            print(f"Dataset: {dataset}, PLCC: {plcc:.4f}, SROCC: {srocc:.4f}")
        print("\n")
